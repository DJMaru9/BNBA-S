/**
 * BNBA SPPG — Backend API
 * Badan Gizi Nasional · SPPG Bantaeng Gantarangkeke
 *
 * CARA PASANG
 * 1. Buat Spreadsheet baru, salin ID-nya dari URL, tempel di SS_ID.
 * 2. Extensions > Apps Script, tempel seluruh file ini.
 * 3. Jalankan fungsi setup() sekali (buat sheet + header otomatis).
 * 4. Deploy > New deployment > Web app
 *      Execute as       : Me
 *      Who has access   : Anyone
 *    Salin URL /exec, tempel di halaman Pengaturan aplikasi.
 * 5. Ganti TOKEN di bawah dengan kata sandi bebas, isi juga di aplikasi.
 */

const SS_ID = '';                 // <-- ID Spreadsheet
const TOKEN = 'ubah-token-ini';   // <-- samakan dengan token di aplikasi

const SHEETS = { sekolah: 'BNBA_SEKOLAH', tigab: 'BNBA_3B', master: 'MASTER_SEKOLAH' };

const HEADERS = {
  sekolah: ['id','nik','nisn','nama','jk','tempat_lahir','tgl_lahir','sekolah','jenjang',
            'kelas','rombel','peran','porsi','alamat','desa','kecamatan','wali','hp','status','updated_at'],
  tigab:   ['id','nik','nama','jk','tgl_lahir','kategori','detail','posyandu',
            'alamat','desa','kecamatan','wali','hp','status','updated_at'],
  master:  ['nama','jenjang','desa','kecil','besar','guru','tendik']
};

/* ---------- setup ---------- */

function setup() {
  const ss = SpreadsheetApp.openById(SS_ID);
  Object.keys(SHEETS).forEach(function (key) {
    let sh = ss.getSheetByName(SHEETS[key]);
    if (!sh) sh = ss.insertSheet(SHEETS[key]);
    if (sh.getLastRow() === 0) {
      sh.getRange(1, 1, 1, HEADERS[key].length).setValues([HEADERS[key]]);
      sh.getRange(1, 1, 1, HEADERS[key].length)
        .setFontWeight('bold').setBackground('#166B45').setFontColor('#FFFFFF');
      sh.setFrozenRows(1);
    }
    // seluruh kolom sebagai teks — cegah Sheets memformat ulang tanggal/NIK
    sh.getRange(1, 1, sh.getMaxRows(), HEADERS[key].length).setNumberFormat('@');
  });
  return 'Sheet siap.';
}

/* ---------- router ---------- */

function doPost(e) {
  let req = {};
  try { req = JSON.parse(e.postData.contents); } catch (err) { return out({ ok: false, error: 'Body tidak valid' }); }
  if (req.token !== TOKEN) return out({ ok: false, error: 'Token salah' });

  const lock = LockService.getScriptLock();
  try {
    lock.waitLock(25000);
    switch (req.action) {
      case 'list':       return out({ ok: true, data: list(req.dataset) });
      case 'listAll':    return out({ ok: true, data: { sekolah: list('sekolah'), tigab: list('tigab'), master: list('master') } });
      case 'save':       return out({ ok: true, data: save(req.dataset, req.payload) });
      case 'remove':     return out({ ok: true, data: remove(req.dataset, req.payload) });
      case 'replaceAll': return out({ ok: true, data: replaceAll(req.dataset, req.payload) });
      default:           return out({ ok: false, error: 'Aksi tidak dikenal: ' + req.action });
    }
  } catch (err) {
    return out({ ok: false, error: String(err) });
  } finally {
    try { lock.releaseLock(); } catch (err2) {}
  }
}

function doGet() {
  return ContentService.createTextOutput('BNBA SPPG API aktif.')
    .setMimeType(ContentService.MimeType.TEXT);
}

function out(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

/* ---------- operasi data ---------- */

function sheetOf(dataset) {
  const name = SHEETS[dataset];
  if (!name) throw new Error('Dataset tidak dikenal: ' + dataset);
  const sh = SpreadsheetApp.openById(SS_ID).getSheetByName(name);
  if (!sh) throw new Error('Sheet ' + name + ' belum dibuat. Jalankan setup().');
  return sh;
}

function list(dataset) {
  const sh = sheetOf(dataset);
  const cols = HEADERS[dataset];
  const last = sh.getLastRow();
  if (last < 2) return [];
  const values = sh.getRange(2, 1, last - 1, cols.length).getDisplayValues();
  return values
    .filter(function (r) { return String(r[0]).trim() !== ''; })
    .map(function (r) {
      const o = {};
      cols.forEach(function (c, i) { o[c] = r[i]; });
      return o;
    });
}

/** Upsert satu batch baris. payload = array objek. */
function save(dataset, rows) {
  const sh = sheetOf(dataset);
  const cols = HEADERS[dataset];
  const last = sh.getLastRow();
  const ids = last > 1 ? sh.getRange(2, 1, last - 1, 1).getDisplayValues().map(function (r) { return r[0]; }) : [];
  const index = {};
  ids.forEach(function (id, i) { index[id] = i + 2; });

  const stamp = Utilities.formatDate(new Date(), 'Asia/Makassar', 'yyyy-MM-dd HH:mm:ss');
  const appends = [];

  rows.forEach(function (row) {
    if (!row.id) row.id = newId();
    row.updated_at = stamp;
    const line = cols.map(function (c) { return row[c] == null ? '' : String(row[c]); });
    if (index[row.id]) {
      sh.getRange(index[row.id], 1, 1, cols.length).setValues([line]);
    } else {
      appends.push(line);
    }
  });

  if (appends.length) {
    const start = sh.getLastRow() + 1;
    sh.getRange(start, 1, appends.length, cols.length).setNumberFormat('@').setValues(appends);
  }
  return { saved: rows.length, added: appends.length };
}

/** Hapus baris berdasar daftar id. Sheet ditulis ulang agar cepat untuk ratusan baris. */
function remove(dataset, idList) {
  const sh = sheetOf(dataset);
  const cols = HEADERS[dataset];
  const last = sh.getLastRow();
  if (last < 2) return { removed: 0 };

  const values = sh.getRange(2, 1, last - 1, cols.length).getDisplayValues()
    .filter(function (r) { return String(r[0]).trim() !== ''; });
  const target = {};
  idList.forEach(function (id) { target[id] = true; });

  const keep = values.filter(function (r) { return !target[r[0]]; });
  const removed = values.length - keep.length;

  sh.getRange(2, 1, last - 1, cols.length).clearContent();
  if (keep.length) {
    sh.getRange(2, 1, keep.length, cols.length).setNumberFormat('@').setValues(keep);
  }
  return { removed: removed };
}

/** Ganti seluruh isi dataset — dipakai saat impor massal. */
function replaceAll(dataset, rows) {
  const sh = sheetOf(dataset);
  const cols = HEADERS[dataset];
  const last = sh.getLastRow();
  if (last > 1) sh.getRange(2, 1, last - 1, cols.length).clearContent();

  const stamp = Utilities.formatDate(new Date(), 'Asia/Makassar', 'yyyy-MM-dd HH:mm:ss');
  const lines = rows.map(function (row) {
    if (!row.id) row.id = newId();
    row.updated_at = stamp;
    return cols.map(function (c) { return row[c] == null ? '' : String(row[c]); });
  });

  if (lines.length) {
    sh.getRange(2, 1, lines.length, cols.length).setNumberFormat('@').setValues(lines);
  }
  return { total: lines.length };
}

function newId() {
  return 'PM' + Date.now().toString(36).toUpperCase() +
         Math.floor(Math.random() * 1296).toString(36).toUpperCase().padStart(2, '0');
}
